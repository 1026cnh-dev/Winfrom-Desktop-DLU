using System;
using System.Collections;
using System.IO;
using System.Windows.Forms;

namespace BT3
{
    public partial class Form1 : Form
    {
        ArrayList dsSV = new ArrayList();
        bool daThayDoi = false;

        // Khởi tạo form và tạo các điều khiển giao diện.
        public Form1()
        {
            InitializeComponent();
        }

        // Xác định file DSNV.txt: dùng file trong dự án khi chạy từ bin, hoặc file cạnh EXE khi phát hành.
        string FilePath
        {
            get
            {
                // Khi chạy từ bin/Debug hoặc bin/Release, dùng file trong dự án.
                string projectDirectory = Path.GetFullPath(
                    Path.Combine(Application.StartupPath, "..", ".."));
                if (File.Exists(Path.Combine(projectDirectory, "BT3.csproj")))
                    return Path.Combine(projectDirectory, "DSNV.txt");

                // Khi chạy bản đã phát hành, dùng file cạnh BT3.exe.
                return Path.Combine(Application.StartupPath, "DSNV.txt");
            }
        }

        // Tìm sinh viên theo MSSV; trả về vị trí trong danh sách, hoặc -1 nếu không tìm thấy.
        int Tim(string mssv)
        {
            for (int i = 0; i < dsSV.Count; i++)
                if (((SinhVien)dsSV[i]).MSSV == mssv) return i;
            return -1;
        }

        // Đọc DSNV.txt vào danh sách trong bộ nhớ; bỏ qua dòng không đủ trường dữ liệu.
        void DocFile()
        {
            dsSV.Clear();
            if (!File.Exists(FilePath)) return;
            foreach (string line in File.ReadAllLines(FilePath))
            {
                SinhVien sv = SinhVien.FromFileLine(line);
                if (sv != null) dsSV.Add(sv);
            }
        }

        // Ghi danh sách vào file tạm rồi thay DSNV.txt sau khi ghi xong để bảo vệ dữ liệu cũ.
        void GhiFile()
        {
            string path = FilePath;
            string tempPath = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
            try
            {
                using (StreamWriter sw = new StreamWriter(tempPath))
                    foreach (SinhVien sv in dsSV)
                        sw.WriteLine(sv.ToFileLine());

                // Chỉ thay file dữ liệu sau khi ghi xong toàn bộ danh sách.
                if (File.Exists(path)) File.Replace(tempPath, path, null);
                else File.Move(tempPath, path);
            }
            finally
            {
                if (File.Exists(tempPath))
                {
                    try { File.Delete(tempPath); }
                    catch (IOException) { }
                    catch (UnauthorizedAccessException) { }
                }
            }
        }

        // Xóa các dòng đang hiển thị và nạp lại bảng từ danh sách sinh viên trong bộ nhớ.
        void LoadListView()
        {
            lvSinhVien.Items.Clear();
            foreach (SinhVien sv in dsSV)
            {
                ListViewItem it = new ListViewItem(sv.MSSV);
                it.SubItems.AddRange(new[] {
                    sv.HoTen, sv.Phai ? "Nam" : "Nữ",
                    sv.NgaySinh.ToString("dd/MM/yyyy"),
                    sv.Lop, sv.SoDT, sv.Email, sv.DiaChi, sv.Hinh
                });
                lvSinhVien.Items.Add(it);
            }
        }

        // Lấy dữ liệu từ các ô nhập trên form để tạo một đối tượng SinhVien.
        SinhVien GetForm()
        {
            return new SinhVien
            {
                MSSV = mtxtMSSV.Text.Trim(),
                HoTen = txtHoTen.Text.Trim(),
                Phai = rdNam.Checked,
                NgaySinh = dtpNgaySinh.Value,
                Lop = cboLop.Text,
                SoDT = mtxtSDT.Text.Trim(),
                Email = txtEmail.Text.Trim(),
                DiaChi = txtDiaChi.Text.Trim(),
                Hinh = txtHinh.Text.Trim()
            };
        }

        // Đưa thông tin sinh viên được chọn lên các ô nhập và hiển thị hình nếu file tồn tại.
        void SetForm(SinhVien sv)
        {
            mtxtMSSV.Text = sv.MSSV;
            txtHoTen.Text = sv.HoTen;
            rdNam.Checked = sv.Phai;
            rdNu.Checked = !sv.Phai;
            if (sv.NgaySinh.Year > 1900) dtpNgaySinh.Value = sv.NgaySinh;
            cboLop.Text = sv.Lop;
            mtxtSDT.Text = sv.SoDT;
            txtEmail.Text = sv.Email;
            txtDiaChi.Text = sv.DiaChi;
            txtHinh.Text = sv.Hinh;
            pbHinh.ImageLocation = File.Exists(sv.Hinh) ? sv.Hinh : "";
        }

        // Khi mở form, đọc dữ liệu từ file, hiển thị lên bảng và đánh dấu chưa có thay đổi.
        private void Form1_Load(object sender, EventArgs e)
        {
            DocFile();
            LoadListView();
            daThayDoi = false;
        }

        // Mở hộp thoại chọn ảnh rồi điền đường dẫn và hiển thị ảnh trên form.
        private void btnChonHinh_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "Image|*.bmp;*.jpg;*.png";
            if (dlg.ShowDialog() != DialogResult.OK) return;
            txtHinh.Text = pbHinh.ImageLocation = dlg.FileName;
        }

        // Xóa nội dung nhập và đưa các lựa chọn trên form về giá trị mặc định.
        private void btnMacDinh_Click(object sender, EventArgs e)
        {
            mtxtMSSV.Clear();
            txtHoTen.Clear();
            txtEmail.Clear();
            txtDiaChi.Clear();
            txtHinh.Clear();
            mtxtSDT.Clear();
            rdNam.Checked = true;
            dtpNgaySinh.Value = DateTime.Now;
            if (cboLop.Items.Count > 0) cboLop.SelectedIndex = 0;
            pbHinh.ImageLocation = "";
        }

        // Đóng form; sự kiện FormClosing sẽ xử lý các thay đổi chưa lưu.
        private void btnThoat_Click(object sender, EventArgs e)
        {
            Close();
        }

        // Kiểm tra MSSV, thêm hoặc cập nhật sinh viên, ghi file ngay và cập nhật bảng khi lưu thành công.
        private void btnLuu_Click(object sender, EventArgs e)
        {
            SinhVien sv = GetForm();
            if (!mtxtMSSV.MaskCompleted)
            {
                MessageBox.Show("MSSV phải gồm 7 số!");
                return;
            }
            ArrayList danhSachCu = (ArrayList)dsSV.Clone();
            int i = Tim(sv.MSSV);
            if (i >= 0) dsSV[i] = sv;
            else dsSV.Add(sv);

            try
            {
                GhiFile();
            }
            catch (IOException ex)
            {
                dsSV = danhSachCu;
                MessageBox.Show("Không thể lưu file: " + FilePath + "\n" + ex.Message);
                return;
            }
            catch (UnauthorizedAccessException ex)
            {
                dsSV = danhSachCu;
                MessageBox.Show("Không có quyền ghi file: " + FilePath + "\n" + ex.Message);
                return;
            }

            daThayDoi = false;
            LoadListView();
            foreach (ListViewItem item in lvSinhVien.Items)
            {
                if (item.Text != sv.MSSV) continue;
                item.Selected = true;
                item.EnsureVisible();
                break;
            }
        }

        // Khi chọn một dòng trong bảng, tìm sinh viên tương ứng và đưa dữ liệu lên form.
        private void lvSinhVien_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lvSinhVien.SelectedItems.Count == 0) return;
            int i = Tim(lvSinhVien.SelectedItems[0].Text);
            if (i >= 0) SetForm((SinhVien)dsSV[i]);
        }

        // Xóa các sinh viên đang được chọn khỏi danh sách, cập nhật bảng và đánh dấu chưa lưu.
        private void mnuXoa_Click(object sender, EventArgs e)
        {
            if (lvSinhVien.SelectedItems.Count == 0) return;
            for (int k = lvSinhVien.SelectedItems.Count - 1; k >= 0; k--)
            {
                int i = Tim(lvSinhVien.SelectedItems[k].Text);
                if (i >= 0) dsSV.RemoveAt(i);
            }
            daThayDoi = true;
            LoadListView();
            btnMacDinh.PerformClick();
        }

        // Đọc lại dữ liệu đã lưu trong DSNV.txt, thay danh sách hiện tại và cập nhật bảng.
        private void mnuTaiLai_Click(object sender, EventArgs e)
        {
            DocFile();
            LoadListView();
            daThayDoi = false;
        }

        // Khi còn thay đổi chưa lưu, cho phép lưu, bỏ thay đổi hoặc hủy đóng form; báo lỗi nếu ghi thất bại.
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!daThayDoi) return;
            DialogResult result = MessageBox.Show("Danh sách đã đổi. Lưu DSNV.txt?", "Xác nhận",
                MessageBoxButtons.YesNoCancel);
            if (result == DialogResult.Cancel)
            {
                e.Cancel = true;
                return;
            }
            if (result != DialogResult.Yes) return;

            try
            {
                GhiFile();
                daThayDoi = false;
            }
            catch (IOException ex)
            {
                e.Cancel = true;
                MessageBox.Show("Không thể lưu file: " + FilePath + "\n" + ex.Message);
            }
            catch (UnauthorizedAccessException ex)
            {
                e.Cancel = true;
                MessageBox.Show("Không có quyền ghi file: " + FilePath + "\n" + ex.Message);
            }
        }
    }
}
