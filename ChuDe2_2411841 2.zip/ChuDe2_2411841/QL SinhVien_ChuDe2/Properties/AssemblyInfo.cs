using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("BT3")]
[assembly: AssemblyProduct("BT3")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: ComVisible(false)]
[assembly: Guid("a1b2c3d4-e5f6-7890-abcd-ef1234567890")]
