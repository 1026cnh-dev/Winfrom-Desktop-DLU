using System;
using System.Windows.Forms;

namespace BT3
{
    internal static class Program
    {
        // Điểm bắt đầu chương trình: thiết lập giao diện Windows Forms và mở Form1.
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
