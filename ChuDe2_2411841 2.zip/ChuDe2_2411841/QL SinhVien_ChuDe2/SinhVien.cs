using System;

namespace BT3
{
    public class SinhVien
    {
        public string MSSV { get; set; }
        public string HoTen { get; set; }
        public bool Phai { get; set; } // true = Nam
        public DateTime NgaySinh { get; set; }
        public string Lop { get; set; }
        public string SoDT { get; set; }
        public string Email { get; set; }
        public string DiaChi { get; set; }
        public string Hinh { get; set; }

        // Chuyển thông tin sinh viên thành một dòng gồm 9 trường, phân cách bằng ký tự tab để lưu file.
        public string ToFileLine()
        {
            return string.Join("\t",
                MSSV,
                HoTen,
                Phai ? "1" : "0",
                NgaySinh.ToString("dd/MM/yyyy"),
                Lop,
                SoDT,
                Email,
                DiaChi,
                Hinh);
        }

        // Đọc một dòng phân cách bằng tab thành SinhVien; trả về null nếu có ít hơn 8 trường.
        public static SinhVien FromFileLine(string line)
        {
            string[] s = line.Split('\t');
            if (s.Length < 8)
                return null;

            DateTime ns;
            if (!DateTime.TryParseExact(s[3], new[] { "dd/MM/yyyy", "d/M/yyyy" },
                System.Globalization.CultureInfo.InvariantCulture,
                System.Globalization.DateTimeStyles.None, out ns))
                DateTime.TryParse(s[3], out ns);

            return new SinhVien
            {
                MSSV = s[0],
                HoTen = s[1],
                Phai = s[2] == "1",
                NgaySinh = ns,
                Lop = s[4],
                SoDT = s[5],
                Email = s[6],
                DiaChi = s[7],
                Hinh = s.Length > 8 ? s[8] : ""
            };
        }
    }
}
